// import React, { createContext, useState, useContext } from 'react';

// const WatchListContext = createContext();

// // export const useWatchList = () => useContext(WatchListContext);
// export const WatchListProvider = ({ children }) => {
//     const [watchList, setWatchList] = useState([]);
//     const addMovie = (movie) => {
//         setWatchList((prevList) => [...prevList, movie]);
//     };
//     const removeMovie = (movieId) => {
//         setWatchList((prevList) => prevList.filter(movie => movie.id !== movieId));
//     };

//     return (
//         <WatchListContext.Provider value={{ watchList, addMovie, removeMovie }}>
//             {children}
//         </WatchListContext.Provider>
//     );
// };

// export const useWatchList = () => {
//     return useContext(WatchListContext);
//   };

//   import React, { createContext, useState, useContext } from 'react';

// const WatchListContext = createContext();

// export const WatchListProvider = ({ children }) => {
//     const [watchList, setWatchList] = useState([]);

//     const addMovie = (movie) => {
//         setWatchList((prevList) => [...prevList, movie]);
//     };

//     const removeMovie = (movieId) => {
//         setWatchList((prevList) => prevList.filter(movie => movie.id !== movieId));
//     };

//     return (
//         <WatchListContext.Provider value={{ watchList, addMovie, removeMovie }}>
//             {children}
//         </WatchListContext.Provider>
//     );
// };

// export const useWatchList = () => useContext(WatchListContext);

import React, { createContext, useState, useContext } from 'react';

const WatchListContext = createContext();

export const WatchListProvider = ({ children }) => {
    const [watchList, setWatchList] = useState([]);

    const addMovie = (movie) => {
        setWatchList((prevList) => [...prevList, movie]);
    };

    const removeMovie = (movieId) => {
        setWatchList((prevList) => prevList.filter(movie => movie.id.toString() !== movieId));
    };

    return (
        <WatchListContext.Provider value={{ watchList, addMovie, removeMovie }}>
            {children}
        </WatchListContext.Provider>
    );
};

export const useWatchList = () => useContext(WatchListContext);




