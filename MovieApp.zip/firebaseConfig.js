// import { initializeApp } from 'firebase/app';
// import { getAuth } from 'firebase/auth';

// const firebaseConfig = {
//     apiKey: "AIzaSyDOfQJaPGfgKKVcub1zATwDBxP5VImLXrU",
//     authDomain: "movieapp-f03af.firebaseapp.com",
//     projectId: "movieapp-f03af",
//     storageBucket: "movieapp-f03af.appspot.com",
//     messagingSenderId: "781817994278",
//     appId: "1:781817994278:web:bb90fd0a61348f14f85ae7"
// };
// const app = initializeApp(firebaseConfig);
// const auth = getAuth(app);

// export { auth };


// import { initializeApp } from 'firebase/app';
// import { getAuth } from 'firebase/auth';
// import { getFirestore } from 'firebase/firestore';

// const firebaseConfig = {
//   apiKey: "YOUR_API_KEY",
//   authDomain: "YOUR_AUTH_DOMAIN",
//   projectId: "YOUR_PROJECT_ID",
//   storageBucket: "YOUR_STORAGE_BUCKET",
//   messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
//   appId: "YOUR_APP_ID"
// };

// const firebaseConfig = {
//     apiKey: "AIzaSyDOfQJaPGfgKKVcub1zATwDBxP5VImLXrU",
//     authDomain: "movieapp-f03af.firebaseapp.com",
//     projectId: "movieapp-f03af",
//     storageBucket: "movieapp-f03af.appspot.com",
//     messagingSenderId: "781817994278",
//     appId: "1:781817994278:web:bb90fd0a61348f14f85ae7"
// };

// const app = initializeApp(firebaseConfig);
// const auth = getAuth(app);
// const db = getFirestore(app);

// export { auth, db };

// import { initializeApp } from 'firebase/app';
// import { getAuth } from 'firebase/auth';
// import { getFirestore } from 'firebase/firestore';
// // import AsyncStorage from '@react-native-async-storage/async-storage';

// // const firebaseConfig = {
// //   apiKey: 'YOUR_API_KEY',
// //   authDomain: 'YOUR_AUTH_DOMAIN',
// //   projectId: 'YOUR_PROJECT_ID',
// //   storageBucket: 'YOUR_STORAGE_BUCKET',
// //   messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
// //   appId: 'YOUR_APP_ID',
// // };

// const firebaseConfig = {
//     apiKey: "AIzaSyAkY9Z9CHii_1c8X-4u4pT5uhPbDVBYn_0",
//     authDomain: "atmdproject-d9978.firebaseapp.com",
//     projectId: "atmdproject-d9978",
//     storageBucket: "atmdproject-d9978.appspot.com",
//     messagingSenderId: "750988986508",
//     appId: "1:750988986508:web:50561c995669c75aaf13a9"
//   };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);

// // Export Firebase services
// const auth = getAuth(app);
// const firestore = getFirestore(app);

// export { auth, firestore };

import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

// const firebaseConfig = {
//     apiKey: "YOUR_API_KEY",
//     authDomain: "YOUR_AUTH_DOMAIN",
//     projectId: "YOUR_PROJECT_ID",
//     storageBucket: "YOUR_STORAGE_BUCKET",
//     messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
//     appId: "YOUR_APP_ID",
// };
const firebaseConfig = {
  apiKey: "AIzaSyAkY9Z9CHii_1c8X-4u4pT5uhPbDVBYn_0",
  authDomain: "atmdproject-d9978.firebaseapp.com",
  projectId: "atmdproject-d9978",
  storageBucket: "atmdproject-d9978.appspot.com",
  messagingSenderId: "750988986508",
  appId: "1:750988986508:web:50561c995669c75aaf13a9"
};
const app = initializeApp(firebaseConfig);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});
const firestore = getFirestore(app);

export { auth, firestore };


