import React from 'react';
import { View, Text, Button, StyleSheet, Alert } from 'react-native';
import { signOut } from 'firebase/auth';
import { useColor } from '../ColorContext';
import { auth } from '../firebaseConfig';

const LogoutScreen = ({ navigation }) => {
    const { color } = useColor();

    const handleLogout = async () => {
        try {
            await signOut(auth);
            navigation.replace('Login'); 
        } catch (error) {
            Alert.alert('Logout Error', error.message);
        }
    };

    return (
        <View style={[styles.container, { backgroundColor: color }]}>
            <Text style={[styles.message, { color: color === '#ffffff' ? '#000000' : '#ffffff' }]}>
                Logged out successfully. Thanks for visiting!
            </Text>
            <Button title="Login Again" onPress={handleLogout} color={color} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    message: {
        fontSize: 18,
        textAlign: 'center',
        marginBottom: 20,
    },
});

export default LogoutScreen;