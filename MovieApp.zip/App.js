import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Login from './authentication/Login';
import Register from './authentication/Register';
import MovieListScreen from './Screens/MovieListScreen';
import MovieDetailScreen from './Screens/MovieDetailScreen';
import SettingScreen from './Screens/SettingScreen';
import WatchListScreen from './Screens/WatchListScreen';
import AboutScreen from './Screens/AboutScreen';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebaseConfig';
import { ColorProvider, useColor } from './ColorContext';
import { WatchListProvider } from './WatchListProvider';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const HomeStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="MovieList" component={MovieListScreen} />
    <Stack.Screen name="MovieDetail" component={MovieDetailScreen} />
  </Stack.Navigator>
);

const AppTabs = () => {
  const { color } = useColor();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          switch (route.name) {
            case 'HomeStack':
              iconName = 'movie';
              break;
            case 'WatchList':
              iconName = 'list';
              break;
            case 'Settings':
              iconName = 'settings';
              break;
            case 'About':
              iconName = 'info';
              break;
            default:
              iconName = 'help';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: color,
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: {
          backgroundColor: '#f8f8f8',
          borderTopWidth: 0,
          elevation: 0,
        },
        tabBarLabelStyle: {
          fontSize: 14,
          marginBottom: 5,
        },
      })}
    >
      <Tab.Screen name="HomeStack" component={HomeStack} options={{ title: 'Movies' }} />
      <Tab.Screen name="WatchList" component={WatchListScreen} options={{ title: 'Watch List' }} />
      <Tab.Screen name="Settings" component={SettingScreen} options={{ title: 'Settings' }} />
      <Tab.Screen name="About" component={AboutScreen} options={{ title: 'About' }} />
    </Tab.Navigator>
  );
};

const App = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    return () => unsubscribe();
  }, []);

  return (
    <ColorProvider>
      <WatchListProvider>
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName={user ? 'AppTabs' : 'Login'}
            screenOptions={{ headerShown: false }}
          >
            {user ? (
              <Stack.Screen name="AppTabs" component={AppTabs} />
            ) : (
              <>
                <Stack.Screen name="Login" component={Login} />
                <Stack.Screen name="Register" component={Register} />
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </WatchListProvider>
    </ColorProvider>
  );
};

export default App;
