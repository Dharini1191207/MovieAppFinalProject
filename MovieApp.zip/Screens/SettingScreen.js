import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import ColorPicker from 'react-native-wheel-color-picker';
import { useColor } from '../ColorContext';

const SettingScreen = () => {
    const { color, setColor } = useColor();
    const [customColor, setCustomColor] = useState(color);

    const handleChangeColor = (newColor) => {
        setCustomColor(newColor);
    };

    const applyColor = () => {
        setColor(customColor);
    };

    return (
        <View style={styles.container}>
            <Text style={[styles.title, { color }]}>Settings</Text>
            <Text style={styles.subtitle}>Choose a color for the app:</Text>
            <ColorPicker
                color={customColor}
                onColorChange={handleChangeColor}
                style={styles.colorPicker}
            />
            <TouchableOpacity
                style={[styles.applyButton, { backgroundColor: customColor }]}
                onPress={applyColor}
            >
                <Text style={styles.applyButtonText}>Apply Color</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#f8f8f8',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    subtitle: {
        fontSize: 18,
        marginBottom: 20,
        textAlign: 'center',
        color: '#666',
    },
    colorPicker: {
        width: 300,
        height: 300,
        marginBottom: 20,
    },
    applyButton: {
        padding: 12,
        borderRadius: 8,
        alignItems: 'center',
        width: 200,
    },
    applyButtonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});

export default SettingScreen;
