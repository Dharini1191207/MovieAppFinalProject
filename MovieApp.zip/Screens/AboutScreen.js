import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { useColor } from '../ColorContext';
import { signOut } from 'firebase/auth';
import { auth } from '../firebaseConfig';

const AboutScreen = ({ navigation }) => {
    const { color } = useColor();

    const handleLogout = async () => {
        try {
            await signOut(auth);
            navigation.replace('Login'); 
        } catch (error) {
            Alert.alert('Logout Error', "Error in logging out! Please Try Again!");
        }
    };

    return (
        <View style={styles.container}>
            <Text style={[styles.title, { color }]}>About This App</Text>
            <Text style={styles.description}>
                This app allows users to browse and manage their favorite movies. Users can add to or remove from the watchlist, search through the movie list, and use a color theme of their choice.
            </Text>
            <Text style={styles.developedBy}>Developed by Dharini and Urvish</Text>
            <TouchableOpacity
                style={[styles.logoutButton, { backgroundColor: color }]}
                onPress={handleLogout}
            >
                <Text style={styles.logoutButtonText}>Logout</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#f8f8f8',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    description: {
        fontSize: 20,
        marginBottom: 20,
        textAlign: 'center',
        color: '#666',
        lineHeight: 24,
    },
    developedBy: {
        fontSize: 18,
        marginBottom: 30,
        textAlign: 'center',
        color: '#888',
    },
    logoutButton: {
        paddingVertical: 12,
        paddingHorizontal: 25,
        borderRadius: 8,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 5,
    },
    logoutButtonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});

export default AboutScreen;
