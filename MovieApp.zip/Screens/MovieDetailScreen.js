import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Button, Alert } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { useColor } from '../ColorContext';
import { useWatchList } from '../WatchListProvider';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { firestore, auth } from '../firebaseConfig';

const MovieDetailScreen = () => {
  const route = useRoute();
  const { movie } = route.params || {};
  const [isAdded, setIsAdded] = useState(false);
  const { color } = useColor();
  const { addMovie } = useWatchList();

  useEffect(() => {
    const checkIfAdded = async () => {
      if (movie) {
        const user = auth.currentUser;
        if (user) {
          const docRef = doc(firestore, `users/${user.uid}/watchlist`, movie.id.toString());
          const docSnap = await getDoc(docRef);
          setIsAdded(docSnap.exists());
        }
      }
    };
    checkIfAdded();
  }, [movie]);

  const addToWatchListHandler = async () => {
    try {
      const user = auth.currentUser;
      if (user) {
        const docRef = doc(firestore, `users/${user.uid}/watchlist`, movie.id.toString());
        await setDoc(docRef, {
          image: movie.poster_path,
          name: movie.title,
          rating: movie.vote_average,
          movieId: movie.id.toString(),
        });
        addMovie(movie);
        setIsAdded(true);
        Alert.alert('Success', `${movie.title} has been added to your watch list!`);
      }
    } catch (error) {
      console.error('Error adding movie to watch list:', error);
    }
  };

  if (!movie) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Movie not found</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Image
        source={{ uri: `https://image.tmdb.org/t/p/w500${movie.backdrop_path}` }}
        style={styles.backdrop}
      />
      <View style={styles.detailsContainer}>
        <Text style={styles.title}>{movie.title}</Text>
        <Text style={styles.releaseDate}>Release Date: {movie.release_date}</Text>
        <Text style={styles.overview}>{movie.overview}</Text>
        <Text style={styles.rating}>Rating: {movie.vote_average}</Text>
        {!isAdded && (
          <Button
            title="Add to Watch List"
            onPress={addToWatchListHandler}
            color={color}
          />
        )}
        {isAdded && <Text style={styles.addedText}>Added to Watch List</Text>}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  backdrop: {
    width: '100%',
    height: 250,
    marginBottom: 20,
  },
  detailsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#333',
  },
  releaseDate: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
    color: '#666',
  },
  overview: {
    fontSize: 16,
    marginVertical: 10,
    lineHeight: 22,
    color: '#444',
    textAlign: 'justify',
  },
  rating: {
    fontSize: 16,
    marginVertical: 10,
    textAlign: 'center',
    color: '#666',
  },
  addedText: {
    marginTop: 20,
    fontSize: 16,
    color: 'green',
    textAlign: 'center',
  },
});

export default MovieDetailScreen;
