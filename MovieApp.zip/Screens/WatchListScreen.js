import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, FlatList, TouchableOpacity, Alert, Button } from 'react-native';
import { useColor } from '../ColorContext';
import { useWatchList } from '../WatchListProvider';
import { collection, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { firestore, auth } from '../firebaseConfig';

const WatchListScreen = () => {
  const { color } = useColor();
  const [watchList, setWatchList] = useState([]);
  const { removeMovie } = useWatchList();

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      const unsubscribe = onSnapshot(collection(firestore, `users/${user.uid}/watchlist`), (snapshot) => {
        const movies = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setWatchList(movies);
      });
      return () => unsubscribe();
    }
  }, []);

  const handleRemove = async (movieId) => {
    try {
      const user = auth.currentUser;
      if (user) {
        await deleteDoc(doc(firestore, `users/${user.uid}/watchlist`, movieId.toString()));
        removeMovie(movieId);
        Alert.alert('Success', 'Movie removed from watch list.');
      }
    } catch (error) {
      console.error('Error removing movie from watch list:', error);
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Image
        source={{ uri: `https://image.tmdb.org/t/p/w500${item.image}` }}
        style={styles.poster}
      />
      <View style={styles.textContainer}>
        <Text style={[styles.movieTitle, { color }]}>{item.name}</Text>
        <Text style={[styles.voteAverage, { color }]}>Rating: {item.rating}</Text>
        <TouchableOpacity style={[styles.removeButton, { backgroundColor: color }]} onPress={() => handleRemove(item.movieId)}>
          <Text style={[styles.removeButtonText,]}>Remove</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {watchList.length === 0 ? (
        <Text style={{ fontSize: 20, marginBottom: 20, color: color }}>Your watch list is empty</Text>
      ) : (
        <FlatList
          data={watchList}
          renderItem={renderItem}
          keyExtractor={(item) => item.movieId.toString()}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    paddingVertical: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    alignItems: 'center',
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: '#f8f8f8',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  poster: {
    width: 80,
    height: 120,
    marginRight: 15,
    borderRadius: 8,
  },
  textContainer: {
    flex: 1,
  },
  movieTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  voteAverage: {
    fontSize: 16,
    marginVertical: 5,
  },
  removeButton: {
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  removeButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default WatchListScreen;
